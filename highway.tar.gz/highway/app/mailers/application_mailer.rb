class ApplicationMailer < ActionMailer::Base
  #default from: "#{ENV['USER']}@sandelman.ca"
  layout 'mailer'
end

