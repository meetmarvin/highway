class VouchersController < ApplicationController
  before_action :require_admin

end
