class OwnersController < ApplicationController
  before_filter :require_admin

end
