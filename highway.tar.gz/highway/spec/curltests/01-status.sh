#!/bin/sh

curl --cacert db/cert/vendor_secp384r1.crt https://highway-test.example.com/status.json

