#!/bin/sh

curl --data-binary @curlreq.json http://localhost:3000/requestvoucher
