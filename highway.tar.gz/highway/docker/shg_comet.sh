#!/bin/sh

docker build -t mcr314/shg_comet:marchbreak .
