docker build -t mcr314/shg_ruby_all:marchbreak -f Dockerfile.short .
