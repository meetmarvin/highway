class OpenSSL::PKey::EC
  def private?
    private_key?
  end
end


